@app.route('/pdf-lesson-planner', methods=['POST'])
def pdf_lesson_planner():
    try:
        if 'file' not in request.files:
            return jsonify({'message': 'No file part'}), 400

        file = request.files['file']
        if file.filename == '':
            return jsonify({'message': 'No selected file'}), 400

        if file and allowed_file(file.filename):
            pdfReader = PyPDF2.PdfReader(io.BytesIO(file.read()))

            text = ""
            for page in range(len(pdfReader.pages)):
                text += pdfReader.pages[page].extract_text()

            lesson_plan_json = generate_lesson_plan(text)
            lesson_plan_dict = json.loads(lesson_plan_json)

            # Extracting values from the lesson_plan_dict
            outlines = lesson_plan_dict.get("outlines", "")
            mcqs = lesson_plan_dict.get("mcqs", [])
            table = lesson_plan_dict.get("table", "")
            activities = lesson_plan_dict.get("activities", "")

            # Generate in-depth lecture
            in_depth_lecture = generate_indepth_lecture_pdf(text)

            # Return the lesson plan, in-depth lecture, and other details
            return jsonify({
                'lesson_plan': {
                    'outlines': outlines,
                    'mcqs': mcqs,
                    'activities': activities
                },
                'in_depth_lecture': in_depth_lecture
            }), 200
        else:
            return jsonify({'message': 'Invalid file type'}), 400

    except Exception as e:
        print(e)
        return jsonify({'message': str(e)}), 500



def generate_lesson_plan(text):
    try:
        system_message_pdf = """\
        Crea un piano di lezione basato sul testo estratto dal file PDF.
        Il piano di lezione deve avere sei sezioni:
        1- Schemi per comprendere il contenuto.
        2- Un semplice quiz a risposta multipla (25 domande).
        4- Consigli su possibili attività educative da svolgere.
        
        Rispondi nel seguente formato JSON:
        {
            "outlines": "Gli schemi vanno qui",
            "mcqs": [
                {
                    "question": "<la domanda va qui>",
                    "correctAnswer": "<la risposta corretta va qui>",
                    "options": ["elenco delle opzioni"]
                },
                ...
            ],
            "activities": "Le attività vanno qui, separa anche ciascuna attività con una nuova riga"
        }
        """

        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": system_message_pdf},
                # Prefix with language
                {"role": "user", "content": f"Italian: {text}"},
            ],
        )
        lesson_plan = response.choices[0].message.content
        return lesson_plan

    except Exception as e:
        print(e)
        raise CustomError(
            "Errore nella generazione del piano di lezione dal PDF.")


def generate_indepth_lecture_pdf(text):
    try:
        system_message_indepth_lecture_pdf_incomplete = """
        E costruisci una lezione approfondita di 9-10 paragrafi contenenti 1000 parole ciascuno, basata sul testo estratto dal file PDF.
        Assicurati di creare un piano di lezione lungo e completo, composto da almeno 4000 a 8000 parole.
        Puoi andare con 7-8 paragrafi per questa lezione.
        Genera sempre la tua risposta in italiano. Rispondi nel seguente formato JSON:
        {
            "in_depth_lecture": "La lezione approfondita va qui"
        }
        """

        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": system_message_indepth_lecture_pdf_incomplete},
                # Prefix with language
                {"role": "user", "content": f"Italian: {text}"},
            ],
        )
        in_depth_lecture = response.choices[0].message.content
        return in_depth_lecture

    except Exception as e:
        print(e)
        raise CustomError(
            "Errore nella generazione della lezione approfondita dal PDF.")
